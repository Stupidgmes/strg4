// Hello there, if you find this page jus know that this is used for imadejptr.
// I don't suggest to get rid of it because it could effect the game entirely

console.log(
    "%c▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒\n▒▒▒▒▒▒▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░▒▒\n▒▒▒▒▒▒░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░\n▒▒▒▒▒▒▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒░░░░░░░░▒▒▒▒░░░░\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▒▒░░░░▒▒▒▒▒▒░░░░\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▒▒░░░░░░░░░░░░░░▓▓▓▓░░▒▒▒▒▒▒▒▒░░░░\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒██░░░░░░░░░░░░░░░░░░░░░░░░▓▓▓▓▒▒▒▒░░░░▒▒\n▒▒▒▒▒▒▒▒▒▒▒▒██░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▓▓▒▒░░░░▒▒\n▒▒▒▒░░▒▒▒▒██▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒\n▒▒▒▒▒▒▒▒▒▒██▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒\n▒▒▒▒▒▒▒▒▓▓▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▓▓▒▒▒▒\n▒▒▒▒▒▒▒▒██▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░██▒▒▒▒\n▒▒▒▒▒▒▒▒██▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░██▒▒▒▒\n▒▒▒▒▒▒▒▒██▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░██▒▒▒▒\n▒▒▒▒▒▒▒▒██▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░██▒▒▒▒\n▒▒▒▒▒▒▒▒██▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░██▒▒▒▒\n▒▒▒▒▒▒▒▒▓▓▓▓▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░▓▓▓▓▒▒▒▒\n▒▒▒▒▒▒▒▒░░██▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░██▒▒▒▒▒▒\n▒▒▒▒▒▒▒▒░░▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░██▒▒▒▒▒▒\n▒▒▒▒▒▒░░░░░░██▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░▒▒▓▓▒▒▒▒▒▒▒▒\n▒▒▒▒▒▒░░░░▒▒▒▒██▒▒▒▒░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▒▒▒▒▒▒▒▒▒\n▒▒▒▒░░░░▒▒▒▒▒▒▒▒░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒████▓▓▒▒▒▒▒▒▒▒▒▒▒▒\n▒▒▒▒░░░░▒▒▒▒░░░░░░░░░░██████████████▒▒▒▒▒▒▒▒▒▒▒▒░░▒▒▒▒\n▒▒▒▒░░░░░░░░░░░░▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒▒▒░░░░░░▒▒\n▒▒▒▒▓▓░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓░░▒▒▒▒\n▒▒▒▒▒▒░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░▒▒▒▒",
    "color: orange"
  );
  
  console.log(
    "%cWELCOME TO IMADEJPTR",
    "font-size: 36px; color: orange; border:1px solid black;"
  );
  console.warn(
    "%cIf you try to take my games you will be hunted down! >:(\n I'm just kidding but contact me at prkrshldn@gmail.com if you want to use my game on your website.",
    "color: orange; border:1px solid black;"
  );
  
  function script(text) {
    console.log(
      "%cInjecting Scripts",
      "color: orange; font-weight: 600; background: black; padding: 0 5px; border-radius: 10px",
      text
    );
  }
  script("Preparing a script to be injected...");
  
  const ga = document.createElement("script");
  ga.setAttribute("async", "");
  ga.setAttribute(
    "src",
    "https://www.googletagmanager.com/gtag/js?id=UA-152753706-1"
  );
  const inline = document.createElement("script");
  inline.innerHTML = `window.dataLayer = window.dataLayer || [];
  
      function gtag() {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
  
      gtag('config', 'UA-152753706-1');`;
  document.head.append(ga, inline);
  script("Injected script 1/1");
  console.log(
    "%cSUCCESS!",
    "color: green; font-size: 24px; font-weight: 600; background: black; padding: 0 5px; border-radius: 10px;"
  );
  